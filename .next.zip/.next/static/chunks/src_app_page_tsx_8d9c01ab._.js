(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4222c6d8._.js",
  "static/chunks/src_597df420._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_40a5578b._.js"
],
    source: "dynamic"
});
