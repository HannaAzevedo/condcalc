(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__404369a3._.css",
  "static/chunks/node_modules_73f53ad2._.js",
  "static/chunks/src_1246dabe._.js"
],
    source: "dynamic"
});
