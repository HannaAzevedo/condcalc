(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_88a33c1d._.js",
  "static/chunks/src_597df420._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_index_208f44ab.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_index_d4b74329.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_caea80d4._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_a644e23c.js",
  "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_37af0cf8.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_de7bca1d._.js"
],
    source: "dynamic"
});
